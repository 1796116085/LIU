//获取元素节点，作用是什么？实现html和js的交互！
//hotWord只是JS中的变量，.hot-word是HTML中定义的，把它们关联！
let hotWord = document.querySelector('.hot-word');//返回文档中与指定的选择器或选择器组匹配的第一个 元素。如果未找到匹配项，则返回。null
let list = document.querySelector('.list');
let search = document.querySelector('.search');
let searchLog = document.querySelector('.search-log');      /*这个是干嘛用的？ */
let form = document.querySelector('.form');
let wrap = document.querySelector('.search>div');
//识别类的
//立即执行函数(function(){})();

//隐藏文本框内容
(function () {
    hotWord.onfocus = function () {
        this.style.color = '#333';
    }
    hotWord.onblur = function () {
        this.style.color = '#999';
    }
})();

//切换输入框的关键字
(function () {
    let hotWor = ['家用电脑', '电脑', '女孩', '户外', '显示器', '图书', '教育', '电子书'];
    //不要让这个变量和上面获取节点的变量定义的一致
    let index = 0;//表示数组下标
    //设置HTML的标准属性，元素节点，属性=“属性值”
    setInterval(function () {
        //定时函数的问题！，元素引用对象！
        index++;            //函数校验
        if (index > hotWor.length - 1) {
            index = 0;                      //可以不停的重复的啊！先不管
        }
        //设置placeholder属性
        hotWord.value = hotWor[index];
    }, 3000);//定时函数
})();

//模糊查询
//input当内容发生改变触发
//change当内容确定改变触发（失去焦点or回车）
//这里有一段代码,加了，上段代码就出现了问题


/*这一行加了，前面一行程序就不显示了 */
/*搜索栏的类容一改变，里面的类容跟着发生改变 */

//轮播图
//这一块定义的东西影响后面的定时函数
let img = document.querySelector('img');        //前面那个获取节点的方式好像有问题，js就是这样，前面的定义有问题，后面就执行不了了！
let imgArr = ['1.png', '2.png', '3.png', '4.png', '5.png', '6.png', '7.png', '8.png'];
//以下定义怕出问题
let prev = document.querySelector('.prev');
let next = document.querySelector('.next');
let lis = document.querySelectorAll('.banner-btn>li');
let slideBanner = document.querySelector('.slide-banner');

//封装切换的函数，包含重新给当前页面附图片和给图片下标赋值
function banner() {
    for (let k = 0; k < lis.length; k++) {              //清空样式，从零开始遍历，全部清空!
        lis[k].className = '';
    }
    //设置图片路径
    img.src = 'images/' + imgArr[i];                    //i下标就是代表哪张图片？
    //设置点的样式
    lis[i].className = 'btn-active';                    //下标样式就会改变
}
//封装自动切换函数
let i = 0;//设置图片下标
function autoBanner() {
    i++;
    if (i > imgArr.length - 1) {
        i = 0;
    }
    console.log("i=" + i);
    banner();
}
setInterval(autoBanner, 3000);

//下一张
next.onclick = function () {
    i++;
    if (i > imgArr.length - 1) {
        i = 0;
    }
    //设置图片路径
    banner();
}
//上一张
prev.onclick = function () {
    i--;
    if (i < 0) {
        i = imgArr.length - 1;
    }
    //设置图片路径
    banner();
}







//点击点
//拿到所有点
//for (let j = 0; j < lis.length; j++) {
//绑定点击事件
//    lis[j].onclick = function () {
//设置图片路径
//        i = j;
//        banner();
//    }
//}

//楼层效果
//当走到主页面的标题，楼层就显示什么样的标题

let elevator = document.querySelector('.elevator');
let header = document.querySelector('.header');                       //导航栏
let items = document.querySelectorAll('.items');                      //这个items指的是四个div距离吗？
let eleA = document.querySelectorAll('.elevator>a');


//最顶部到京东秒杀栏目的距离
let to = header.offsetHeight + slideBanner.offsetHeight + 40;//基础距离为650，和上面敲的还是有距离！

//声名一个数组，存储四个div距上面的距离
let floor = [];
//拿到四个div

//let liu = items.offsetHeight;
//console.log(liu);                             /*这里输出是underfined*/

for (let i = 0; i < items.length; i++) {        /*为啥里面有直接可以console.log,其中items要用数组的形式才能调用！ */
    to = to + items[i].offsetHeight;
    floor.push(to);                             /*原来的floor[]=" ",现在就是floor[]="910"*/
}
console.log(floor);                             /*这里输出是console.log(floor) */

//封装去掉a样式的函数
function clear() {
    for (let i = 0; i < eleA.length; i++) {
        eleA[i].className = '';
    }
}

//给页面绑定滚动监听事件
window.onscroll = function () {
    //获取滚动条距上面的距离
    let top = document.documentElement.scrollTop || document.body.scrollTop;
    //获取元素距上面的距离
    let top1 = header.offsetHeight + slideBanner.offsetHeight + 40;//offset包含border,padding;不包含margin//kelit只包含padding,不包含border
    //判断
    if (top >= top1) {
        //固定定位
        //还是可以识别出来的，因为可以固定定位
        //固定定位样式出了问题
        elevator.className = 'elevator elevator-fix';
    } else {
        elevator.className = 'elevator';
    }
    //楼层效果
    //判断top距上面的距离，对应的a修改字体颜色
    if (top >= top1 && top < floor[0]) {
        clear();
        eleA[0].className = 'active';
    } else if (top >= floor[0] && top <= floor[1]) {
        clear();
        eleA[1].className = 'active';
    } else if (top >= floor[1] && top <= floor[2]) {
        clear();
        eleA[2].className = 'active';
    } else if (top >= floor[2]) {
        clear();
        eleA[3].className = 'active';
    }
    if (top < top1) {
        clear();
    }

    //吸顶效果,调整一下这些样式！
    if (top >= top1 - 62) {
        search.className = 'header-fix';                /*.className会改变search这一栏的类名，变成我们的吸顶样式*/
        /* 如何把.form里面的margin-top值变成8px,和margin-left值变成460px*/
        /* form.style.margin-top='8px'*/
        form.style.marginTop = '8px';
        form.style.marginLeft = '460px';
        searchLog.style.display = 'block';              /*显示京东log*/
        wrap.className = 'wrap';                        /*搜素框中显示水平居中div*/
    } else {
        search.className = 'search';                    /*变成普通样式*/
        form.style.marginTop = '25px';
        form.style.marginLeft = '70px';

        searchLog.style.display = 'none';               /*不显示京东log*/
    }

    //还需要还原吸顶的东西
}





































